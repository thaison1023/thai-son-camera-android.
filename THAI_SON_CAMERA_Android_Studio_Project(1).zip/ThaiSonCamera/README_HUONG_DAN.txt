THÁI SƠN CAMERA — DỰ ÁN ANDROID STUDIO

Gồm:
- Giao diện tiếng Việt tối ưu điện thoại
- Quản lý khách hàng
- Báo giá và mẫu in cao cấp
- Lịch sử lắp đặt
- Quản lý thiết bị
- Phiếu bảo hành
- Theo dõi thu chi
- Quản lý công nợ: tổng phải thu, đã thanh toán, còn nợ, ghi nhận thu nợ
- Trang thông tin liên hệ
- Logo TS Camera tự thiết kế
- Android WebView wrapper tải giao diện từ assets cục bộ

CÁCH TẠO APK TRÊN MÁY TÍNH
1. Cài Android Studio bản ổn định và Android SDK Platform 35.
2. Giải nén gói ZIP.
3. Android Studio > Open > chọn thư mục ThaiSonCamera (thư mục chứa settings.gradle).
4. Chờ Gradle Sync hoàn tất; nếu hỏi cài Android Gradle Plugin hoặc SDK, chọn Install/Accept.
5. Chọn Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Khi build xong, bấm Locate ở thông báo hoặc tìm:
   app/build/outputs/apk/debug/app-debug.apk
7. Chép APK sang điện thoại Android, cho phép cài ứng dụng từ nguồn này nếu hệ thống hỏi, rồi cài đặt.

LƯU Ý QUAN TRỌNG
- Đây là dự án nguồn Android Studio để build APK; môi trường tạo file hiện tại không có Android SDK/Gradle build chain nên không thể xác nhận tạo APK nhị phân ngay tại đây.
- Dữ liệu lưu cục bộ trong WebView của ứng dụng, chưa có đồng bộ đám mây.
- Tính năng in trong WebView có thể tùy thiết bị; để xuất PDF ổn định nhất, bản web chạy trên Chrome có thể dùng chức năng In > Lưu dưới dạng PDF.
- Không dùng thông tin khách hàng thật cho tới khi đã kiểm tra kỹ và sao lưu.
- Thông tin liên hệ ban đầu để trống, hãy nhập số điện thoại/địa chỉ thực trong mục Liên hệ.
